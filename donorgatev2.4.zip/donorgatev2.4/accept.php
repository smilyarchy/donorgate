<div id="pay-invoice">
    <div class="card-body">
        <div class="card-title">
            <h2 style="color: green;" class="text-center">Transaction Successful</h2><br>
            <p class="text-center">Please do not close the browser. You will be automatically redirected.</p>
        </div>
        <hr>
    </div>
    
    <p class="text-center">
        <!-- Credit Card -->
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Read the incoming data
            $rawData = file_get_contents("php://input");

            if ($rawData !== false && !empty($rawData)) {
                $alldata = explode("&", $rawData);
                $status = explode("=", $alldata[1]);
                $amount = explode("=", $alldata[8]);
                $reference = explode("=", $alldata[4]);
                $method = explode("=", $alldata[9]);
                $CardHolderIpAddr = explode("=", $alldata[2]);
                $Extra1 = explode("=", $alldata[7]);

                // Define a mapping array for payment methods
                $methodNames = array(
                    '1' => 'Credit card',
                    '2' => 'Bank EFT',
                    '3' => 'Retail',
                    '4' => 'Ozow',
                    '5' => 'MasterPass',
                    '6' => 'Visa Checkout',
                    '7' => 'Masterpass QR',
                );

                $methodName = isset($methodNames[$method[1]]) ? $methodNames[$method[1]] : 'Unknown';

                echo "<strong>Status : </strong>" . htmlspecialchars($status[1]) . "<br>";
                echo "<strong>Amount : </strong> R" . htmlspecialchars($amount[1]) . "<br>";
                echo "<strong>Reference : </strong> " . htmlspecialchars($reference[1]) . "<br>";
                echo "<strong>Payment Method : </strong>" . htmlspecialchars($methodName) . "<br>";
                echo "<strong>IP Address : </strong>" . htmlspecialchars($CardHolderIpAddr[1]) . "<br>";

                // Decode the JSON data if applicable
                $data = json_decode($rawData, true);
                if ($data !== null) {
                    if (isset($data['payment_status']) && $data['payment_status'] === 'success') {
                        echo "Payment Successful<br>";
                        echo "Amount: " . htmlspecialchars($data['Amount']) . "<br>";
                        echo "Extra Field 1: " . htmlspecialchars($data['Extra1']) . "<br>";
                        echo "Method: " . htmlspecialchars($data['Method']) . "<br>";
                    }
                }
            } else {
                echo "No data received.";
            }
        } else {
            echo "No transaction has been processed. Please complete a transaction to view the details.";
        }
        ?>
    </p>

    <p class="text-center">
        <a href="https://netcash.simali.co.za/donate/" class="btn btn-success" role="button" style="border: 2px solid #28a745; padding: 10px 20px; border-radius: 5px;">
            Click here if you are not redirected
        </a>
    </p>
</div>
