<?php
/*
Plugin Name: DonorGate
Description: A plugin to handle donations through a Netcash payment gateway.
Version: 2.4
Author: Ndivhu Simali
*/

// Enqueue styles for the front-end
function donor_gate_enqueue_styles() {
    wp_enqueue_style('donor-gate-style', plugins_url('style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'donor_gate_enqueue_styles');

// Enqueue styles for the admin area
function donor_gate_admin_enqueue_styles() {
    wp_enqueue_style('donor-gate-admin-style', plugins_url('style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'donor_gate_admin_enqueue_styles');

// Add admin menu for DonorGate Donations and Settings
function donor_gate_add_admin_menu() {
    // Add DonorGate Transactions to the menu
    add_menu_page('DonorGate Donations', 'DonorGate', 'manage_options', 'donor-gate', 'donor_gate_admin_page');

    // Add DonorGate Settings to the Settings menu
    add_options_page('DonorGate Settings', 'DonorGate Settings', 'manage_options', 'donor-gate-settings', 'donor_gate_settings_page');
}
add_action('admin_menu', 'donor_gate_add_admin_menu');

// Register the settings
function donor_gate_register_settings() {
    register_setting('donor_gate_settings_group', 'donor_gate_m1_key');
    register_setting('donor_gate_settings_group', 'donor_gate_display_name');
    register_setting('donor_gate_settings_group', 'donor_gate_display_surname');
    register_setting('donor_gate_settings_group', 'donor_gate_display_email');
    register_setting('donor_gate_settings_group', 'donor_gate_display_mobile');
}
add_action('admin_init', 'donor_gate_register_settings');

// Generate postback URLs dynamically (only on activation)
function donor_gate_generate_postback_urls() {
    $plugin_dir = basename(plugin_dir_path(__FILE__)); // Get the actual plugin folder name
    $base_url = home_url('/'); // Get the domain where WordPress is installed

    // Build the URLs dynamically based on the plugin directory
    $accept_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/accept.php';
    $decline_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/decline.php';
    $notify_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/notify.php';

    // Save the URLs in the options table only if they haven't been set yet
    if (!get_option('donor_gate_accept_url')) {
        update_option('donor_gate_accept_url', $accept_url);
    }
    if (!get_option('donor_gate_decline_url')) {
        update_option('donor_gate_decline_url', $decline_url);
    }
    if (!get_option('donor_gate_notify_url')) {
        update_option('donor_gate_notify_url', $notify_url);
    }
}

// Display the postback URLs at the top of the settings page
function donor_gate_display_postback_urls() {
    $accept_url = get_option('donor_gate_accept_url', '');
    $decline_url = get_option('donor_gate_decline_url', '');
    $notify_url = get_option('donor_gate_notify_url', '');

    echo '<h2>Postback URLs</h2>';
    echo '<p><strong>Accept URL:</strong> ' . esc_html($accept_url) . '</p>';
    echo '<p><strong>Decline URL:</strong> ' . esc_html($decline_url) . '</p>';
    echo '<p><strong>Notify URL:</strong> ' . esc_html($notify_url) . '</p>';
}

// Settings page content
function donor_gate_settings_page() {
    ?>
    <div class="wrap">
        <h1>DonorGate Settings</h1>

        <!-- Display postback URLs above the form -->
        <?php donor_gate_display_postback_urls(); ?>

        <form method="post" action="options.php">
            <?php settings_fields('donor_gate_settings_group'); ?>
            <?php do_settings_sections('donor_gate_settings_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Service Key (M1)</th>
                    <td>
                        <input type="text" name="donor_gate_m1_key" value="<?php echo esc_attr(get_option('donor_gate_m1_key', '')); ?>" placeholder="Enter your M1 service key" />
                    </td>
                </tr>

                <!-- Form field visibility controls -->
                <tr valign="top">
                    <th scope="row">Display Name Field (m4)</th>
                    <td>
                        <input type="checkbox" name="donor_gate_display_name" value="1" <?php checked(get_option('donor_gate_display_name', '1'), '1'); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Display Surname Field (m5)</th>
                    <td>
                        <input type="checkbox" name="donor_gate_display_surname" value="1" <?php checked(get_option('donor_gate_display_surname', '1'), '1'); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Display Email Field (m9)</th>
                    <td>
                        <input type="checkbox" name="donor_gate_display_email" value="1" <?php checked(get_option('donor_gate_display_email', '1'), '1'); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Display Mobile Field (m11)</th>
                    <td>
                        <input type="checkbox" name="donor_gate_display_mobile" value="1" <?php checked(get_option('donor_gate_display_mobile', '1'), '1'); ?> />
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Admin page function to display donations
function donor_gate_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    // Fetch donation data and check for errors
    $donations = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

    if ($wpdb->last_error) {
        // Display an error message if there is a database error
        echo '<div class="error"><p>Error fetching donation records: ' . esc_html($wpdb->last_error) . '</p></div>';
        return;
    }
    
    ?>
    <div class="wrap">
        <h1>DonorGate Donations</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><strong>Reference</strong></th>
                    <th><strong>Name</strong></th>
                    <th><strong>Surname</strong></th>
                    <th><strong>Mobile Number</strong></th>
                    <th><strong>Email Address</strong></th>
                    <th><strong>Amount</strong></th>
                    <th><strong>Status</strong></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($donations) : ?>
                <?php foreach ($donations as $donation) : ?>
                <tr>
                    <td><?php echo esc_html($donation->p2); ?></td>
                    <td><?php echo esc_html($donation->name); ?></td>
                    <td><?php echo esc_html($donation->surname); ?></td>
                    <td><?php echo esc_html($donation->mobile_number); ?></td>
                    <td><?php echo esc_html($donation->email_address); ?></td>
                    <td>R<?php echo esc_html($donation->amount); ?></td>
                    <td><?php echo esc_html($donation->status); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php else : ?>
                <tr>
                    <td colspan="7">No donations found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Handle activation and postback URL generation
function donor_gate_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';
    $charset_collate = $wpdb->get_charset_collate();

    // Create the donations table
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        surname tinytext NOT NULL,
        mobile_number varchar(15) NOT NULL,
        email_address varchar(100) NOT NULL,
        amount float NOT NULL,
        p2 tinytext NOT NULL,
        status varchar(20) DEFAULT 'pending' NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Generate postback
    // Generate postback URLs (only during activation)
    donor_gate_generate_postback_urls();
}
register_activation_hook(__FILE__, 'donor_gate_activate');

// Shortcode for donation form
function donor_gate_form_shortcode() {
    ob_start();

    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    // Get field visibility options
    $display_name = get_option('donor_gate_display_name', '1');
    $display_surname = get_option('donor_gate_display_surname', '1');
    $display_email = get_option('donor_gate_display_email', '1');
    $display_mobile = get_option('donor_gate_display_mobile', '1');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Validate nonce
        if (!isset($_POST['donation_form_nonce']) || !wp_verify_nonce($_POST['donation_form_nonce'], 'donation_form_action')) {
            die('Security check failed!');
        }

        // Sanitize form data or use default values for hidden fields
        $name = ($display_name == '1') ? sanitize_text_field($_POST['m4']) : 'Anonymous';
        $surname = ($display_surname == '1') ? sanitize_text_field($_POST['m5']) : 'Anonymous';
        $email_address = ($display_email == '1') ? sanitize_email($_POST['m9']) : 'noreply@support.co.za';
        $mobile_number = ($display_mobile == '1') ? sanitize_text_field($_POST['m11']) : '0123456789';
        $amount = sanitize_text_field($_POST['p4']);
        $reference = uniqid(); // Generate unique reference

        // Insert form data into the database
        $wpdb->insert(
            $table_name,
            [
                'name' => $name,
                'surname' => $surname,
                'mobile_number' => $mobile_number,
                'email_address' => $email_address,
                'amount' => $amount,
                'p2' => $reference,
                'status' => 'pending',
                'created_at' => current_time('mysql'),
            ]
        );

        // Get the saved M1 key from the settings
        $m1_key = get_option('donor_gate_m1_key', '');

        // Redirect to the payment gateway (Netcash)
        ?>
        <form id="redirect-form" method="POST" action="https://paynow.netcash.co.za/site/paynow.aspx" target="_top">
            <input type="hidden" id="m1" name="m1" value="<?php echo esc_attr($m1_key); ?>" required>
            <input type="hidden" id="m2" name="m2" value="24ade73c-98cf-47b3-99be-cc7b867b3080" required>
            <input type="hidden" name="p2" value="<?php echo $reference; ?>">
            <input type="hidden" name="p3" value="Donation by <?php echo $name . ' ' . $surname; ?>">
            <input type="hidden" name="p4" value="<?php echo $amount; ?>">
            <input type="hidden" name="m4" value="<?php echo $name; ?>">
            <input type="hidden" name="m5" value="<?php echo $surname; ?>">
            <input type="hidden" name="m9" value="<?php echo $email_address; ?>">
            <input type="hidden" name="m11" value="<?php echo $mobile_number; ?>">
        </form>
        <script type="text/javascript">
            document.getElementById('redirect-form').submit();
        </script>
        <?php
        exit;
    }
    ?>

    <!-- Display Donation Form -->
    <form name="donation-form" id="donation-form" method="POST">
        <?php wp_nonce_field('donation_form_action', 'donation_form_nonce'); ?>

        <!-- Name Field (m4) -->
        <?php if ($display_name == '1') : ?>
        <div class="form-row">
            <label for="m4"><strong>Name</strong></label>
            <input type="text" class="form-control" id="m4" name="m4" placeholder="Enter your name">
        </div>
        <?php endif; ?>

        <!-- Surname Field (m5) -->
        <?php if ($display_surname == '1') : ?>
        <div class="form-row">
            <label for="m5"><strong>Surname</strong></label>
            <input type="text" class="form-control" id="m5" name="m5" placeholder="Enter your surname">
        </div>
        <?php endif; ?>

        <!-- Email Field (m9) -->
        <?php if ($display_email == '1') : ?>
        <div class="form-row">
            <label for="m9"><strong>Email Address</strong></label>
            <input type="email" class="form-control" id="m9" name="m9" placeholder="Enter your email address">
        </div>
        <?php endif; ?>

        <!-- Mobile Field (m11) -->
        <?php if ($display_mobile == '1') : ?>
        <div class="form-row">
            <label for="m11"><strong>Mobile Number</strong></label>
            <input type="tel" class="form-control" id="m11" name="m11" placeholder="Enter your mobile number">
        </div>
        <?php endif; ?>

        <input type="hidden" name="p2" id="p2" value="<?php echo uniqid(); ?>"> <!-- Unique Reference -->
        <input type="hidden" name="p3" id="p3" value="">

        <!-- Donation Amount Radio Buttons -->
        <div class="form-row amount-options">
            <label><strong>Donation Amount</strong></label><br>
            <div class="custom-radio-group">
                <label class="custom-radio">
                    <input type="radio" name="amount" value="50" onclick="enableCustomAmount()">
                    <span>R50</span>
                </label>
                <label class="custom-radio">
                    <input type="radio" name="amount" value="100" onclick="enableCustomAmount()">
                    <span>R100</span>
                </label>
                <label class="custom-radio">
                    <input type="radio" name="amount" value="250" onclick="enableCustomAmount()">
                    <span>R250</span>
                </label>
                <label class="custom-radio">
                    <input type="radio" name="amount" value="500" onclick="enableCustomAmount()">
                    <span>R500</span>
                </label>
                <label class="custom-radio">
                    <input type="radio" name="amount" value="1000" onclick="enableCustomAmount()">
                    <span>R1000</span>
                </label>
                <label class="custom-radio">
                    <input type="radio" name="amount" value="Custom" onclick="enableCustomAmount()">
                    <span>Custom Amount</span>
                </label>
            </div>
        </div>

        <!-- Custom Amount Field -->
        <div class="form-row">
            <label for="p4">Amount:</label>
            <input type="text" id="p4" name="p4" class="form-control" value="" readonly required>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Donate Now</button>
    </form>

    <script>
        function enableCustomAmount() {
            const radios = document.getElementsByName('amount');
            let selectedValue = '';
            for (const radio of radios) {
                if (radio.checked) {
                    selectedValue = radio.value;
                    break;
                }
            }
            const customAmountField = document.getElementById('p4');
            if (selectedValue === 'Custom') {
                customAmountField.value = '';
                customAmountField.readOnly = false;
            } else {
                customAmountField.value = selectedValue;
                customAmountField.readOnly = true;
            }
        }
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('donor_gate_form', 'donor_gate_form_shortcode');
?>
