<?php// Admin page function to display donations
function donor_gate_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';
    $donations = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>DonorGate Donations</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <<th><strong>Reference</strong></th>
                    <th><strong>Name</strong></th>
                    <th><strong>Surname</strong></th>
                    <th><strong>Mobile Number</strong></th>
                    <th><strong>Email Address</strong></th>
                    <th><strong>Amount</strong></th>
                    <th><strong>Status</strong></th>
                    
                </tr>
            </thead>
            <tbody>
                <?php foreach ($donations as $donation) : ?>
                <tr>
                    <td><?php echo esc_html($donation->p2); ?></td>
                    <td><?php echo esc_html($donation->name); ?></td>
                    <td><?php echo esc_html($donation->surname); ?></td>
                    <td><?php echo esc_html($donation->mobile_number); ?></td>
                    <td><?php echo esc_html($donation->email_address); ?></td>
                    <td>R<?php echo esc_html($donation->amount); ?></td>
                    <td><?php echo esc_html($donation->status); ?></td>
                   
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
