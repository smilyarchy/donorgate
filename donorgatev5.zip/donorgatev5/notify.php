<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the Notify data
    $transactionAccepted = $_POST['TransactionAccepted'] ?? null;
    $reference = $_POST['Reference'] ?? null;

    // Database connection information
    $host = 'localhost';  // Update these with your DB details
    $username = 'simalico_wp488';  // DB Username
    $password = 'Ndivhudza25?';  // DB Password
    $database = 'simalico_wp488';  // DB Name

    // Create a connection to the database
    $mysqli = new mysqli($host, $username, $password, $database);

    // Check the connection
    if ($mysqli->connect_error) {
        die('Connection failed: ' . $mysqli->connect_error);
    }

    // Check if the necessary data is available
    if (!empty($reference)) {
        // Use a prepared statement to update the status
        $stmt = $mysqli->prepare("UPDATE wpqt_donor_gate_donations SET status = ? WHERE p2 = ?");
        
        // Determine transaction status
        $status = ($transactionAccepted === 'true') ? 'completed' : 'failed';
        
        // Bind parameters
        $stmt->bind_param('ss', $status, $reference);

        // Execute the query
        if ($stmt->execute()) {
            echo 'Status updated successfully';
        } else {
            echo 'Error updating status: ' . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo 'Invalid or incomplete data for updating status.';
    }

    // Close the database connection
    $mysqli->close();
} else {
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Request method not allowed.";
}
?>
