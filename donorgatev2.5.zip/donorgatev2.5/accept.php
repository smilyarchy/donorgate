<div id="pay-invoice" style="max-width: 600px; margin: auto; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); background-color: #f8f9fa;">
    <div class="card-body">
        <div class="card-title" style="text-align: center;">
            <h2 style="color: #28a745; margin-bottom: 15px;">Transaction Successful</h2>
            <p style="font-size: 1.1rem; color: #555;">Please do not close the browser. You will be automatically redirected.</p>
        </div>
        <hr style="border-top: 1px solid #ddd;">
    </div>
    
    <div style="text-align: center; margin-top: 20px;">
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Read the incoming data
            $rawData = file_get_contents("php://input");

            if ($rawData !== false && !empty($rawData)) {
                $alldata = explode("&", $rawData);
                $status = explode("=", $alldata[1]);
                $amount = explode("=", $alldata[8]);
                $reference = explode("=", $alldata[4]);
                $method = explode("=", $alldata[9]);
                $CardHolderIpAddr = explode("=", $alldata[2]);
                $Extra1 = explode("=", $alldata[7]);

                // Define a mapping array for payment methods
                $methodNames = array(
                    '1' => 'Credit card',
                    '2' => 'Bank EFT',
                    '3' => 'Retail',
                    '4' => 'Ozow',
                    '5' => 'MasterPass',
                    '6' => 'Visa Checkout',
                    '7' => 'Masterpass QR',
                    '9' => 'Payflex',
                    '10' => 'Flash1Voucher',
                );

                $methodName = isset($methodNames[$method[1]]) ? $methodNames[$method[1]] : 'Unknown';

                echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Status:</strong> " . htmlspecialchars($status[1]) . "</div>";
                echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Amount:</strong> R" . htmlspecialchars($amount[1]) . "</div>";
                echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Reference:</strong> " . htmlspecialchars($reference[1]) . "</div>";
                echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Payment Method:</strong> " . htmlspecialchars($methodName) . "</div>";

                // Decode the JSON data if applicable
                $data = json_decode($rawData, true);
                if ($data !== null) {
                    if (isset($data['payment_status']) && $data['payment_status'] === 'success') {
                        echo "<div style='font-size: 1.1rem; color: #28a745; margin-top: 15px;'><strong>Payment Successful</strong></div>";
                        echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Amount:</strong> " . htmlspecialchars($data['Amount']) . "</div>";
                        echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Extra Field 1:</strong> " . htmlspecialchars($data['Extra1']) . "</div>";
                        echo "<div style='font-size: 1.1rem; color: #333; margin-bottom: 10px;'><strong>Method:</strong> " . htmlspecialchars($data['Method']) . "</div>";
                    }
                }
            } else {
                echo "<div style='color: #dc3545; font-size: 1.1rem; margin-top: 20px;'>No data received.</div>";
            }
        } else {
            echo "<div style='color: #ffc107; font-size: 1.1rem; margin-top: 20px;'>No transaction has been processed. Please complete a transaction to view the details.</div>";
        }
        ?>
    </div>

    <p style="text-align: center; margin-top: 30px;">
        <a href="https://netcash.simali.co.za/donate/" class="btn" style="background-color: #28a745; color: white; border: none; padding: 12px 20px; border-radius: 5px; text-decoration: none; transition: background-color 0.3s;">
            Click here if you are not redirected
        </a>
    </p>
</div>
