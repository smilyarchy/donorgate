<?php
// Include WordPress environment to access DB constants
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' ); // Adjust path as needed

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the Notify data
    $transactionAccepted = $_POST['TransactionAccepted'] ?? null;
    $reference = $_POST['Reference'] ?? null;

    // Debugging output - Check if we receive POST data correctly
    if (is_null($transactionAccepted) || is_null($reference)) {
        die('Missing required POST data.'); // Debugging statement
    }

    // Access the global $wpdb object to work with the database
    global $wpdb;

    // Use WordPress constants for database connection details
    $host = DB_HOST;
    $username = DB_USER;
    $password = DB_PASSWORD;
    $database = DB_NAME;

    // Create a connection to the database using WordPress credentials
    $mysqli = new mysqli($host, $username, $password, $database);

    // Check the connection
    if ($mysqli->connect_error) {
        die('Connection failed: ' . $mysqli->connect_error);
    }

    // Check if the necessary data is available
    if (!empty($reference)) {
        // Use a prepared statement to update the status
        $table_name = $wpdb->prefix . 'donor_gate_donations'; // Dynamically get the table with prefix
        $stmt = $mysqli->prepare("UPDATE $table_name SET status = ? WHERE p2 = ?");
        
        if (!$stmt) {
            die('Prepare failed: ' . $mysqli->error); // Debugging statement
        }

        // Determine transaction status
        $status = ($transactionAccepted === 'true') ? 'completed' : 'failed';
        
        // Bind parameters
        $stmt->bind_param('ss', $status, $reference);

        // Execute the query
        if ($stmt->execute()) {
            echo 'Status updated successfully';
        } else {
            echo 'Error updating status: ' . $stmt->error; // Debugging statement
        }

        // Close the statement
        $stmt->close();
    } else {
        echo 'Invalid or incomplete data for updating status.';
    }

    // Close the database connection
    $mysqli->close();
} else {
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Request method not allowed.";
}
